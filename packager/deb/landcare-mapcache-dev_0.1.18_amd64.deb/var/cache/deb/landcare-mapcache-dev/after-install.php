<?php
echo "ldconfig...\n";
`ldconfig`;
